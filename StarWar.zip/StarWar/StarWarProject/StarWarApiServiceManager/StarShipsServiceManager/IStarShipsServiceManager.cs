﻿using System.Threading.Tasks;
using StarWarModel.StarShips;

namespace StarWarApiServiceManager.StarShipsServiceManager
{
    public interface IStarWarShipServiceManager
    {
        Task<StarShipsCollection> GetShipsInformation(byte? pageNumber);
    }
}
