﻿using Microsoft.Extensions.Configuration;
using StarWarApiServiceManager.HttpClientWrapper;
using System;
using System.Threading.Tasks;
using Newtonsoft.Json;
using StarWarModel.StarWarShipException;
using StarWarModel.StarShips;
using System.Net;

namespace StarWarApiServiceManager.StarShipsServiceManager
{
    public class StarWarShipServiceManager : IStarWarShipServiceManager
    {
        private readonly IHttpWapper _httpWapper;

        private string _baseUrl;

        private const string controller = "starships";
        public StarWarShipServiceManager(IHttpWapper htpWapper, IConfiguration config)
        {
            _httpWapper = htpWapper;

            _baseUrl = config.GetSection("SarWarApi").Value;
        }

        public async Task<StarShipsCollection> GetShipsInformation(byte? pageNumber)
        {
            string url = pageNumber == null ? $"{_baseUrl}{controller}" : $"{_baseUrl}{controller}/?page={pageNumber}";

            try
            {
                var response = await _httpWapper.GetAsync(url);

                if (!response.IsSuccessStatusCode || response.StatusCode != HttpStatusCode.OK)
                {
                    string message = $"The response from {url} returns with status {response.StatusCode}. It failed to get star ships details.";

                    //TODO Log an error log
                    throw new StarWarShipsException(message);
                }

                var jsonString = await response.Content.ReadAsStringAsync();

                var starShipsResponse = JsonConvert.DeserializeObject<StarShipsCollection>(jsonString);

                return starShipsResponse;

            }
            catch (StarWarShipsException)
            {
                throw;
            }
            catch (Exception ex)
            {
                string message = $"An error occurred while trying to retrieve star ships data from {url}";

                //TODO log an error log
                throw new StarWarShipsException(message, ex);
            }
        }

    }
}
