﻿using System.Net.Http;
using System.Threading.Tasks;

namespace StarWarApiServiceManager.HttpClientWrapper
{
    public interface IHttpWapper 
    {
        /// <summary>
        /// This method is responsible for call the given url to get the data
        /// </summary>
        /// <param name="url">the url for the endpoint</param>
        /// <returns>the responsemessge with the corresponding status code and data </returns>
        Task<HttpResponseMessage> GetAsync(string url);
    }
}
