﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace StarWarApiServiceManager.HttpClientWrapper
{
    public class HttpWapper : IHttpWapper
    {
        public async Task<HttpResponseMessage> GetAsync(string url)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var result = await client.GetAsync(url);

                    return result;
                   
                }
            }
            catch (Exception)
            {
                //TODO Add log 

                throw;
            }
        }

    }
}
