﻿using System;

namespace StarWarShips.ConsoleWapper
{
    public class ConsoleWapper : IConsoleWapper
    {
        public void WriteLine(string value)
        {
            Console.WriteLine(value);
        }

        public string ReadLine()
        {
            return Console.ReadLine();
        }
    }
}
