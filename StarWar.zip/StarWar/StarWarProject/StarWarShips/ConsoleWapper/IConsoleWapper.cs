﻿namespace StarWarShips.ConsoleWapper
{
    public interface IConsoleWapper
    {
        /// <summary>
        /// This method is responsible for writing value to the console
        /// </summary>
        /// <param name="value">the value which need to be write to the console</param>
        void WriteLine(string value);

        /// <summary>
        /// This method is responsiable for read value from the console
        /// </summary>
        /// <returns>the value whiich is read from the console</returns>
        string ReadLine();
    }
}
