﻿using StarShipsBusinessLayer.ShipsResupplyHandler;
using StarWarShips.ConsoleWapper;
using StarWarShips.InputOutputHandler;
using System;

namespace StarWarShips
{
    public class StarShipApp
    {
        private readonly IInputHandler _inputHandler;
        private readonly IShipsResupplyHandler _shipsResupplyHandler;
        private readonly IOutputHandler _outputHandler;
        private readonly IConsoleWapper _consoleWapper;

        public StarShipApp(IInputHandler inputHandler, IShipsResupplyHandler shipsResupplyHandler, IOutputHandler outputHandler, IConsoleWapper consoleWapper)
        {
            _inputHandler = inputHandler;
            _shipsResupplyHandler = shipsResupplyHandler;
            _outputHandler = outputHandler;
            _consoleWapper = consoleWapper;
        }
        /// <summary>
        /// This method is responsible for get the inputed distance and trrigger the calculation then return the result
        /// </summary>
        public void Run()
        {
            try
            {
                var distance = _inputHandler.GetDistance();

                if (distance != null)
                {
                    var shipsResupplyDetails = _shipsResupplyHandler.GetShipsResupplyDetail(distance.Value);

                    _outputHandler.DisplayShipsResupplyDetail(shipsResupplyDetails);
                }
            }
            catch (Exception ex)
            {
                string message = $"There is an error occurred during the process, the detail is display below: ";
                _consoleWapper.WriteLine(message);

                _consoleWapper.WriteLine(ex.Message);

                if (ex.InnerException != null)
                    _consoleWapper.WriteLine(ex.InnerException.Message);
            }

        }
    }
}
