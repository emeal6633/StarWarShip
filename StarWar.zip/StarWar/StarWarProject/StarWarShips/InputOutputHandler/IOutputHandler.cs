﻿using StarWarModel.StarShips;
using System.Collections.Generic;

namespace StarWarShips.InputOutputHandler
{
    public interface IOutputHandler
    {
        /// <summary>
        /// This method is responsible for display the ship resupply details to the console
        /// </summary>
        /// <param name="shipsResupplyDetails">the list of ship resupply details</param>
        void DisplayShipsResupplyDetail(List<ShipResupplyDetail> shipsResupplyDetails);
    }
}
