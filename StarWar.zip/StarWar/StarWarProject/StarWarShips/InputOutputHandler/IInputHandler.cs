﻿namespace StarWarShips.InputOutputHandler
{
    public interface IInputHandler
    {
        /// <summary>
        /// Get the distance value for the console 
        /// </summary>
        /// <returns>the distance vaue if the distance value is valid otherwise null</returns>
        double? GetDistance();
    }
}
