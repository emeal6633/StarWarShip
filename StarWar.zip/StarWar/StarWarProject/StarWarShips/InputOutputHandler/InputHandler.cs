﻿using StarWarShips.ConsoleWapper;

namespace StarWarShips.InputOutputHandler
{
    public class InputHandler : IInputHandler
    {
        private readonly IConsoleWapper _consoleWapper;

        public InputHandler(IConsoleWapper consoleWapper)
        {
            _consoleWapper = consoleWapper;
        }
        public double? GetDistance()
        {
            string description = "This application is used to calculate how many stops for resupply are required for " +
                                 "all star war ships to travel the given distance.";

            _consoleWapper.WriteLine(description);

            _consoleWapper.WriteLine("Please input the distance in mega lights (MGLT):");

            var distanceInput = _consoleWapper.ReadLine();

            string message;

            if (!double.TryParse(distanceInput, out var distance))
            {
                message = $"{distanceInput} is not a valid number";

                _consoleWapper.WriteLine(message);

                return null;
            }
            if (distance <= 0)
            {
                message = $"{distanceInput} is not a positive number";

                _consoleWapper.WriteLine(message);

                return null;
            }

            message = $"Start calcualtion for the total amount of stops required to make the distance {distance}";

            _consoleWapper.WriteLine(message);

            return distance;

        }
    }
}
