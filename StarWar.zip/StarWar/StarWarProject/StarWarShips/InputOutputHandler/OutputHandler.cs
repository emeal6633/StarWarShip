﻿using StarWarModel.StarShips;
using StarWarShips.ConsoleWapper;
using System.Collections.Generic;
using System.Linq;

namespace StarWarShips.InputOutputHandler
{
    public class OutputHandler : IOutputHandler
    {
        private readonly IConsoleWapper _consoleWapper;

        public OutputHandler(IConsoleWapper consoleWapper)
        {
            _consoleWapper = consoleWapper;
        }
        public void DisplayShipsResupplyDetail(List<ShipResupplyDetail> shipsResupplyDetails)
        {
            string message;

            if (shipsResupplyDetails == null || !shipsResupplyDetails.Any())
            {
                message = "There is no star ships information found.";

                _consoleWapper.WriteLine(message);
            }
            else
            {
                message = $"The total amount of stops required to make the distance for each ship are display below: ";

                _consoleWapper.WriteLine(message);

                int shipsCount = 1;

                foreach (ShipResupplyDetail shipResupplyDetail in shipsResupplyDetails)
                {
                    string numberOfStopValue = shipResupplyDetail.NumberOfStops == null ? "unknown" : shipResupplyDetail.NumberOfStops.Value.ToString();

                    message = $"{shipsCount}:  ShipName: {shipResupplyDetail.Name}, The Number of stops：{numberOfStopValue}, MGLT: {shipResupplyDetail.MGLT}, Consumables: {shipResupplyDetail.Consumables}";

                    _consoleWapper.WriteLine(message);

                    shipsCount++;
                }
            }
        }
    }
}
