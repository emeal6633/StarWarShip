﻿using StarWarApiServiceManager;
using System;
using Microsoft.Extensions.DependencyInjection;
using StarWarApiServiceManager.HttpClientWrapper;
using Microsoft.Extensions.Configuration;
using System.IO;
using StarShipsBusinessLayer.ShipsDetailsHandler;
using StarShipsBusinessLayer.ShipsResupplyCalculator;
using StarWarShips;
using StarWarShips.ConsoleWapper;
using StarWarApiServiceManager.StarShipsServiceManager;
using StarWarShips.InputOutputHandler;
using StarShipsBusinessLayer.ShipsResupplyHandler;

namespace StartWarShips
{
    class Program
    {

        static void Main(string[] args)
        {
            var serviceProvider = ConfigureServices();
           
            var starShipApp = serviceProvider.GetService<StarShipApp>();

            //Start run the star war ship application
            starShipApp.Run();

        }


        /// <summary>
        /// This method is responsible for add configuration
        /// </summary>
        /// <returns>the configuration object with the required configuration inforamtion</returns>
        private static IConfiguration AddConfiguraiion()
        {
            var builder = new ConfigurationBuilder()
                 .SetBasePath(Directory.GetCurrentDirectory())
                 .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

            return builder.Build();
        }

        /// <summary>
        /// This method is responsiable for add the services
        /// </summary>
        /// <returns>the sevice provider with the registed services</returns>
        private static ServiceProvider ConfigureServices()
        {
            IServiceCollection services = new ServiceCollection();

            var config = AddConfiguraiion();

            services.AddSingleton(config);
            //Wapper
            services.AddTransient<IHttpWapper, HttpWapper>();
            services.AddTransient<IConsoleWapper, ConsoleWapper>();

            //Input Output handlers
            services.AddScoped<IInputHandler, InputHandler>();
            services.AddScoped<IOutputHandler, OutputHandler>();

            //Services related to star war ships
            services.AddTransient<IStarWarShipServiceManager, StarWarShipServiceManager>();
            services.AddScoped<IShipsDetailHandler, ShipsDetailHandler>();
            services.AddScoped<IShipsResupplyCalculator, ShipsResupplyCalculator>();
            services.AddScoped<IShipsResupplyHandler, ShipsResupplyHandler>();

            //Add the service for the start of the application
            services.AddScoped<StarShipApp>();

            return services.BuildServiceProvider();
        }


    }
}
