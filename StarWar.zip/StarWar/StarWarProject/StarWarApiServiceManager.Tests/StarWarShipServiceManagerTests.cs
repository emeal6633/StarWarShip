using Microsoft.Extensions.Configuration;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;
using StarWarApiServiceManager.HttpClientWrapper;
using StarWarApiServiceManager.StarShipsServiceManager;
using StarWarModel.StarShips;
using StarWarModel.StarWarShipException;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace StarWarShips.Tests
{
    [TestFixture]
    public class StarWarShipServiceManagerTestss
    {
        private Mock<IHttpWapper> mockHttpWapper;
        private Mock<IConfiguration> mockConfig;
        private const string baseUrl = "https://test/";

        [SetUp]
        public void Setup()
        {
            mockHttpWapper = new Mock<IHttpWapper>();
            mockConfig = new Mock<IConfiguration>();
            mockConfig.Setup(f => f.GetSection("SarWarApi").Value).Returns(baseUrl);
        }

        [TearDown]
        public void TearDown()
        {
            mockConfig = null;
            mockHttpWapper = null;
        }

        [Test]
        public void GetShipsInformation_HttpWapperThrowException_ThrowStarWarShipsException()
        {
            //Arrange.
            mockHttpWapper.Setup(f => f.GetAsync($"{baseUrl}starships")).ThrowsAsync(new Exception("Boom"));

            var serviceManager = new StarWarShipServiceManager(mockHttpWapper.Object, mockConfig.Object);

            //Act. => Assert.
            var exception = Assert.ThrowsAsync<StarWarShipsException>(async () => await serviceManager.GetShipsInformation(null));

            string expectedMessge = $"An error occurred while trying to retrieve star ships data from {$"{baseUrl}starships"}";
            Assert.AreEqual(expectedMessge, exception.Message);
            Assert.IsInstanceOf<Exception>(exception.InnerException);
            Assert.AreEqual("Boom", exception.InnerException.Message);
        }

        [Test]
        public async Task GetShipsInformation_ValidData_ReturnStarShipsCollection()
        {
            //Arrange.
            var collection = GetStarShipsCollection();
            var response = GetHttpResponse(collection, HttpStatusCode.OK);

            mockHttpWapper.Setup(f => f.GetAsync($"{baseUrl}starships")).ReturnsAsync(response);

            var serviceManager = new StarWarShipServiceManager(mockHttpWapper.Object, mockConfig.Object);

            //Act.
            var result = await serviceManager.GetShipsInformation(null);

            //Assert
            Assert.AreEqual(collection.Count, result.Count);
            Assert.AreEqual(collection.Next, result.Next);
            Assert.AreEqual(collection.Results.Count, result.Results.Count);
        }

        [Test]
        public async Task GetShipsInformation_PassPageNumber_ReturnStarShipsCollection()
        {
            //Arrange.
            var collection = GetStarShipsCollection();
            var response = GetHttpResponse(collection, HttpStatusCode.OK);

            byte pageNumber = 1;

            string url = $"{baseUrl}starships/?page={pageNumber}";

            mockHttpWapper.Setup(f => f.GetAsync(url)).ReturnsAsync(response);

            var serviceManager = new StarWarShipServiceManager(mockHttpWapper.Object, mockConfig.Object);

            //Act.
            var result = await serviceManager.GetShipsInformation(pageNumber);

            //Assert
            Assert.AreEqual(collection.Count, result.Count);
            Assert.AreEqual(collection.Next, result.Next);
            Assert.AreEqual(collection.Results.Count, result.Results.Count);

            mockHttpWapper.Verify(f => f.GetAsync(url), Times.Once );
        }

        [Test]
        public void GetShipsInformation_HttpWapperReturnBadRequest_ThrowStarWarShipsException()
        {
            //Arrange.
            var collection = GetStarShipsCollection();

            var response = GetHttpResponse(collection, HttpStatusCode.BadRequest);

            byte pageNumber = 1;

            string url = $"{baseUrl}starships/?page={pageNumber}";

            mockHttpWapper.Setup(f => f.GetAsync(url)).ReturnsAsync(response);

            var serviceManager = new StarWarShipServiceManager(mockHttpWapper.Object, mockConfig.Object);

            //Act. => Assert.
            var exception = Assert.ThrowsAsync<StarWarShipsException>(async() => await serviceManager.GetShipsInformation(pageNumber));

            string expectedmMessage = $"The response from {url} returns with status {response.StatusCode}. It failed to get star ships details.";

            Assert.AreEqual(expectedmMessage, exception.Message);
            Assert.IsNull(exception.InnerException);
        }


        private HttpResponseMessage GetHttpResponse(StarShipsCollection content, HttpStatusCode statusCode )
        {    
            var jsonContent = JsonConvert.SerializeObject(content);

            var response = new HttpResponseMessage
            {
                StatusCode = statusCode,
                Content = new StringContent(jsonContent)
            };

            return response;
        }

        private StarShipsCollection GetStarShipsCollection()
        {
            var collection = new StarShipsCollection
            {
                Count = 1,
                Next = "haha",
                Results = new List<StarShip>()
            };

            return collection;
        }
    }
}