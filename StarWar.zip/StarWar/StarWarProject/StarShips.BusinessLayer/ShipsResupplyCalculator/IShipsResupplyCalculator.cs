﻿using StarWarModel;
using StarWarModel.StarShips;
using System.Collections.Generic;

namespace StarShipsBusinessLayer.ShipsResupplyCalculator
{
    public interface IShipsResupplyCalculator
    {
        /// <summary>
        /// The property for given distance value
        /// </summary>
        double Distance { get; set; }
        /// <summary>
        /// This method is responsible for calculate the number of stops all the ships required for a given distance
        /// </summary>
        /// <param name="ships">the list of ships with the MGLT and Consumables</param>
        /// <returns>the list of ship resuppl details with the number of stops required and the ship details</returns>
        List<ShipResupplyDetail> CalculateShipsResupplyStopNumber(List<StarShip> ships);
    }
}
