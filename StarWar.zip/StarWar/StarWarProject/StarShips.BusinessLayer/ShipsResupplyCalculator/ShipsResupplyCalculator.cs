﻿using StarShipsBusinessLayer.ShipsResupplyCalculator;
using StarWarModel;
using StarWarModel.StarShips;
using StarWarModel.StarWarShipException;
using System;
using System.Collections.Generic;

namespace StarShipsBusinessLayer.ShipsResupplyCalculator
{
    public class ShipsResupplyCalculator : IShipsResupplyCalculator
    {
        /// <summary>
        /// It is represents the given distance which need be calculated
        /// </summary>
        public double Distance { get; set; }

        public List<ShipResupplyDetail> CalculateShipsResupplyStopNumber(List<StarShip> ships)
        {
            try
            {
                var shipsResupplyDetail = new List<ShipResupplyDetail>();

                foreach (StarShip ship in ships)
                {
                    var shipResupplyDetail = CalculateSingleShipResupplyStopNumber(ship);

                    shipsResupplyDetail.Add(shipResupplyDetail);
                }

                return shipsResupplyDetail;
            }
            catch (NotSupportedException)
            {
                throw;
            }
            catch (Exception ex)
            {
                string message = $"An error occurred while trying to calcualte ship resupply stop numbers for distance {Distance}";

                //TODO Log an error
                throw new StarWarShipsException(message, ex);
            }
        }

        /// <summary>
        /// This method is responsible for calculate the number of stops for a individual ship with the given distance
        /// </summary>
        /// <param name="ship">the ship object which includes the ship MGLT and consumables</param>
        /// <returns>the ShipResupplyDetail object with the number of stops and the ship details</returns>
        private ShipResupplyDetail CalculateSingleShipResupplyStopNumber(StarShip ship)
        {
            var shipResupplyDetail = new ShipResupplyDetail
            {
                Name = ship.Name,
                Consumables = ship.Consumables,
                MGLT = ship.MGLT
            };

            var consumablesInHours = ConvertConsumablesIntoHours(ship.Consumables);

            if (consumablesInHours != null && ValidateStringValue(ship.MGLT))
            {
                if (double.TryParse(ship.MGLT, out var mglt))
                {
                    var stops = Distance / mglt / consumablesInHours - 1;

                    var roundedStops = (int)Math.Ceiling(stops.Value);

                    shipResupplyDetail.NumberOfStops = roundedStops;
                }          
            }

            return shipResupplyDetail;
        }

        /// <summary>
        /// This method is responsible for validating the value is valid or not
        /// </summary>
        /// <param name="value">the value need to be validated</param>
        /// <returns>a bool which indicate if the value is valid or not</returns>
        private bool ValidateStringValue(string value)
        {
            var valid = !string.IsNullOrEmpty(value) && !string.Equals(value, "unknown", StringComparison.InvariantCultureIgnoreCase);

            return valid;
        }

        /// <summary>
        /// This method is responsible for convert the consumables into the consumables value in hours
        /// </summary>
        /// <param name="consumables">the given consumables which need to be converted to the consumables value in hours</param>
        /// <returns>the consumables value in hours if the consumables is convertable otherwise null</returns>
        private int? ConvertConsumablesIntoHours(string consumables)
        {
            if (!ValidateStringValue(consumables))
                return null;

            switch (consumables)
            {
                case string years when years.Contains("year", StringComparison.InvariantCultureIgnoreCase):

                    return ConvertConsumablesIntoHoursByGivenPeriod(consumables, 365 * 24);

                case string months when months.Contains("month", StringComparison.InvariantCultureIgnoreCase):

                    return ConvertConsumablesIntoHoursByGivenPeriod(consumables, 30 * 24);

                case string weeks when weeks.Contains("week", StringComparison.InvariantCultureIgnoreCase):

                    return ConvertConsumablesIntoHoursByGivenPeriod(consumables, 7 * 24);

                case string days when days.Contains("day", StringComparison.InvariantCultureIgnoreCase):

                    return ConvertConsumablesIntoHoursByGivenPeriod(consumables, 24);

                case string hours when hours.Contains("hour", StringComparison.InvariantCultureIgnoreCase):

                    return ConvertConsumablesIntoHoursByGivenPeriod(consumables, 1);

                default:
                    string message = $"convert consumables {consumables} to hours is not support";

                    throw new NotSupportedException(message);
            }

        }

        /// <summary>
        /// This method is responsible for converting the consumables value to the consumables value in hours 
        /// by the given equal value in hours per unit
        /// </summary>
        /// <param name="consumables">The maximum length of time that this starship can provide consumables for its entire crew without having to resupply</param>
        /// <param name="numberOfHours">The number of hours per unit, e.g. the number of hours for a week should be 7*24</param>
        /// <returns>The consumables in hours if the consumables is convertable otehrwise null </returns>
        private int? ConvertConsumablesIntoHoursByGivenPeriod(string consumables, int numberOfHours)
        {
            if (!int.TryParse(consumables.Substring(0, consumables.IndexOf(" ")), out var consumablesNumber))
            {
                return null;
            }

            return consumablesNumber * numberOfHours;

        }
    }
}
