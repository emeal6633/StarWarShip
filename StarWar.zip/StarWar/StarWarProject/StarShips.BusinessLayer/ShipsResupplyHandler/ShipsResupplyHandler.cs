﻿
using StarShipsBusinessLayer.ShipsDetailsHandler;
using StarShipsBusinessLayer.ShipsResupplyCalculator;
using StarWarModel.StarShips;
using StarWarModel.StarWarShipException;
using System;
using System.Collections.Generic;

namespace StarShipsBusinessLayer.ShipsResupplyHandler
{
    public class ShipsResupplyHandler : IShipsResupplyHandler
    {
        private readonly IShipsDetailHandler _shipsDetailsHandlers;
        private readonly IShipsResupplyCalculator _shipsResupplyCalculator;

        public ShipsResupplyHandler(IShipsDetailHandler shipsDetailHandler, IShipsResupplyCalculator shipsResupplyCalculator)
        {
            _shipsDetailsHandlers = shipsDetailHandler;
            _shipsResupplyCalculator = shipsResupplyCalculator;
        }

        public List<ShipResupplyDetail> GetShipsResupplyDetail(double distance)
        {
            try
            {
                var shipList = _shipsDetailsHandlers.CombineShipsDetail();

                shipList.Wait();

                _shipsResupplyCalculator.Distance = distance;

                var shipsResupplyDetails = _shipsResupplyCalculator.CalculateShipsResupplyStopNumber(shipList.Result);

                return shipsResupplyDetails;
            }
            catch (StarWarShipsException)
            {
                throw;
            }
            catch (Exception ex)
            {
                string message = $"An error occurred while trying to get ships details and process resupply calculation with the distance {distance} ";
                
                //TODo log an error
                throw new StarWarShipsException(message, ex);
            }
        }
    }
}
