﻿using StarWarModel.StarShips;
using System;
using System.Collections.Generic;
using System.Text;

namespace StarShipsBusinessLayer.ShipsResupplyHandler
{
    public interface IShipsResupplyHandler
    {
        /// <summary>
        /// This method is responsible for get the ships resupply information for all star war ships for the given distance
        /// </summary>
        /// <param name="distance">the travel distance in MGLT</param>
        /// <returns>the list of ships resupply details for the given travel distance</returns>
        List<ShipResupplyDetail> GetShipsResupplyDetail(double distance);
    }
}
