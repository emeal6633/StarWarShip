﻿using StarWarModel;
using StarWarModel.StarShips;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace StarShipsBusinessLayer.ShipsDetailsHandler
{
    public interface IShipsDetailHandler
    {
        Task<List<StarShip>> CombineShipsDetail();
    }
}
