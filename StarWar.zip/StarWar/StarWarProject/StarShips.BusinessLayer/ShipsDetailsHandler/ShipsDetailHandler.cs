﻿using StarWarApiServiceManager.StarShipsServiceManager;
using StarWarModel.StarShips;
using StarWarModel.StarWarShipException;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace StarShipsBusinessLayer.ShipsDetailsHandler
{
    public class ShipsDetailHandler : IShipsDetailHandler
    {
        private readonly IStarWarShipServiceManager _starWarShipServiceManager;

        public ShipsDetailHandler(IStarWarShipServiceManager starWarShipServiceManager)
        {
            _starWarShipServiceManager = starWarShipServiceManager;
        }
        public async Task<List<StarShip>> CombineShipsDetail()
        {
            int shipTotalCount = 0;

            int currentShipsCount = 0;

            byte currrentPageNumber = 1;

            try
            {
                var shipsCollection = await _starWarShipServiceManager.GetShipsInformation(null);

                shipTotalCount = shipsCollection.Count;

                currentShipsCount = shipsCollection.Results.Count;

                var shipsList = shipsCollection.Results;

                while (shipTotalCount > currentShipsCount && !string.IsNullOrEmpty(shipsCollection.Next))
                {
                    currrentPageNumber++;

                    shipsCollection = await _starWarShipServiceManager.GetShipsInformation(currrentPageNumber);

                    shipsList.AddRange(shipsCollection.Results);

                    currentShipsCount = currentShipsCount + shipsCollection.Results.Count;
                }

                var combinedShipCount = shipsList.Count;

                if (combinedShipCount != shipTotalCount)
                {
                    string message = $"The combined ships list has {combinedShipCount} is not equal to the expected ships nubmer {shipTotalCount}.";

                    //TODO log an error
                    throw new StarWarShipsException(message);
                }

                return shipsList;
            }
            catch (StarWarShipsException)
            {
                throw;
            }
            catch (Exception ex)
            {
                string message = $"An error occurred while trying to combline {shipTotalCount} number of star ships information with current count of ships {currentShipsCount} and the ships information page number {currrentPageNumber}";

                //TODO log an error
                throw new StarWarShipsException(message, ex);
            }

        }
    }
}
