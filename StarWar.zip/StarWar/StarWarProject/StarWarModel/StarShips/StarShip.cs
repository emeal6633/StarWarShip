﻿namespace StarWarModel.StarShips
{
    /// <summary>
    /// This model represents the star ship model which includes the detail of the ship
    /// </summary>
    public class StarShip
    {
        /// <summary>
        /// It presents the name of the star ship
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        ///It presents the maximum length of time that this starship can provide consumables for its entire crew without having to resupply
        /// </summary>
        public string Consumables { get; set; }

        /// <summary>
        /// It presents the maximum number of Megalights this starship can travel in a standard hour. 
        /// </summary>
        public string MGLT { get; set; }

    }
}
