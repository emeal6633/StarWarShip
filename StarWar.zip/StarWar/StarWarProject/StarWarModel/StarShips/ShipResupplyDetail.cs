﻿namespace StarWarModel.StarShips
{
    public class ShipResupplyDetail : StarShip
    {
        public int? NumberOfStops { get; set; } = null;
    
    }
}
