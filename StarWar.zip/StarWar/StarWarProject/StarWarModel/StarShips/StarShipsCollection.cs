﻿using System.Collections.Generic;
namespace StarWarModel.StarShips
{
    /// <summary>
    /// This model represents the collection of the starships and the related information
    /// </summary>
    public class StarShipsCollection
    {
        /// <summary>
        /// It represents the total number of star ships
        /// </summary>
        public int Count { get; set; }

        /// <summary>
        /// It represents the url for next page to get other star ships inforamtion
        /// </summary>
        public string Next { get; set; }

        /// <summary>
        /// The list of star ships from the current page
        /// </summary>
        public List<StarShip> Results { get; set; }
    }
}

