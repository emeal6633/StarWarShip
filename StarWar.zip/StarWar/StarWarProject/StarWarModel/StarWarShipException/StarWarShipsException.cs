﻿
using System;

namespace StarWarModel.StarWarShipException
{
    public class StarWarShipsException : Exception
    {
        public StarWarShipsException(string message) : base(message) { }

        public StarWarShipsException(string message, Exception exception) : base(message, exception) { }
    }
}
