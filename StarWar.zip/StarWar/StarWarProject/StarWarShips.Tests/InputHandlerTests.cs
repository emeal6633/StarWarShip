﻿using Moq;
using NUnit.Framework;
using StarWarShips.ConsoleWapper;
using StarWarShips.InputOutputHandler;

namespace StarWarShips.Tests
{
    [TestFixture]
    public class InputHandlerTests
    {
        private Mock<IConsoleWapper> mockConsoleWapper;
        [SetUp]
        public void SetUp()
        {
            mockConsoleWapper = new Mock<IConsoleWapper>();

        }

        [TearDown]
        public void TearDown()
        {
            mockConsoleWapper = null;
        }

        [Test]
        public void GetDistance_DistanceIsNotNumber_ReturnNull()
        {
            //Arrange.
            mockConsoleWapper.Setup(f => f.ReadLine()).Returns("aa");

            var inputHandler = new InputHandler(mockConsoleWapper.Object);

            //Act.
            var result = inputHandler.GetDistance();

            //Assert.
            Assert.IsNull(result);

            string message = "This application is used to calculate how many stops for resupply are required for " +
                                 "all star war ships to travel the given distance.";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Once);

            message = "Please input the distance in mega lights (MGLT):";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Once);

            message = "aa is not a valid number";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Once);

            message = "aa is not a positive number";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Never);

            message = "Start calcualtion for the total amount of stops required to make the distance aa";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Never);
        }

        [Test]
        public void GetDistance_DistanceIsNegativeNumber_ReturnNull()
        {
            //Arrange.
            mockConsoleWapper.Setup(f => f.ReadLine()).Returns("-1");

            var inputHandler = new InputHandler(mockConsoleWapper.Object);

            //Act.
            var result = inputHandler.GetDistance();

            //Assert.
            Assert.IsNull(result);

            string message = "This application is used to calculate how many stops for resupply are required for " +
                                 "all star war ships to travel the given distance.";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Once);

            message = "Please input the distance in mega lights (MGLT):";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Once);

            message = "-1 is not a positive number";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Once);

            message = "-1 is not a valid number";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Never);

            message = "Start calcualtion for the total amount of stops required to make the distance -1";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Never);
        }

        [Test]
        public void GetDistance_DistanceIsNegativeNumber_ReturnThePassedInNumber()
        {
            //Arrange.
            mockConsoleWapper.Setup(f => f.ReadLine()).Returns("2");

            var inputHandler = new InputHandler(mockConsoleWapper.Object);

            //Act.
            var result = inputHandler.GetDistance();

            //Assert.
            Assert.AreEqual(2, result);

            string message = "This application is used to calculate how many stops for resupply are required for " +
                                 "all star war ships to travel the given distance.";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Once);

            message = "Please input the distance in mega lights (MGLT):";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Once);

            message = "Start calcualtion for the total amount of stops required to make the distance 2";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Once);

            message = "2 is not a positive number";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Never);

            message = "2 is not a valid number";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Never);
        }
    }
}
