﻿using Moq;
using NUnit.Framework;
using StarWarModel.StarShips;
using StarWarShips.ConsoleWapper;
using StarWarShips.InputOutputHandler;
using System;
using System.Collections.Generic;
using System.Text;

namespace StarWarShips.Tests
{
    [TestFixture]
   public class OutputHandlerTests
    {
        private Mock<IConsoleWapper> mockConsoleWapper;

        [SetUp]
        public void SetUp()
        {
            mockConsoleWapper = new Mock<IConsoleWapper>();
        }

        [TearDown]
        public void TearDown()
        {
            mockConsoleWapper = null;
        }

        [Test]
        public void DisplayShipsResupplyDetail_ShupResupplyListEmpty_DisPlayNoShipFoundMessage()
        {
            //Arrange
            var shipsResupplyList = new List<ShipResupplyDetail>();

            var outputHandler = new OutputHandler(mockConsoleWapper.Object);

            //Act.
            outputHandler.DisplayShipsResupplyDetail(shipsResupplyList);

            //Assert.
            mockConsoleWapper.Verify(f => f.WriteLine(It.IsAny<string>()), Times.Once);
            mockConsoleWapper.Verify(f => f.WriteLine("There is no star ships information found."), Times.Once);
        }

        [Test]
        public void DisplayShipsResupplyDetail_ValidShipsResupplyList_DisPlayShipsResupplDetail()
        {
            //Arrange
            var shipsResupplyList = new List<ShipResupplyDetail>
            {
                new ShipResupplyDetail
                {
                    NumberOfStops = 2,
                    Name = "Boom",
                    Consumables = "3 years",
                    MGLT = "40"
                }
            };

            var outputHandler = new OutputHandler(mockConsoleWapper.Object);

            //Act.
            outputHandler.DisplayShipsResupplyDetail(shipsResupplyList);

            //Assert.
            mockConsoleWapper.Verify(f => f.WriteLine(It.IsAny<string>()), Times.Exactly(2));
            mockConsoleWapper.Verify(f => f.WriteLine($"The total amount of stops required to make the distance for each ship are display below: "), Times.Once);

            string message = $"1:  ShipName: Boom, The Number of stops：2, MGLT: 40, Consumables: 3 years";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Once);
        }

        [Test]
        public void DisplayShipsResupplyDetail_NumberOfStopsIsNull_DisplayUnknownAsNumberOfStops()
        {
            //Arrange
            var shipsResupplyList = new List<ShipResupplyDetail>
            {
                new ShipResupplyDetail
                {
                    NumberOfStops = null,
                    Name = "Boom",
                    Consumables = "3 years",
                    MGLT = "40"
                }
            };

            var outputHandler = new OutputHandler(mockConsoleWapper.Object);

            //Act.
            outputHandler.DisplayShipsResupplyDetail(shipsResupplyList);

            //Assert.
            mockConsoleWapper.Verify(f => f.WriteLine(It.IsAny<string>()), Times.Exactly(2));
            mockConsoleWapper.Verify(f => f.WriteLine($"The total amount of stops required to make the distance for each ship are display below: "), Times.Once);

            string message = $"1:  ShipName: Boom, The Number of stops：unknown, MGLT: 40, Consumables: 3 years";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Once);
        }

    }
}
