﻿using Moq;
using NUnit.Framework;
using StarShipsBusinessLayer.ShipsResupplyHandler;
using StarWarModel.StarShips;
using StarWarModel.StarWarShipException;
using StarWarShips.ConsoleWapper;
using StarWarShips.InputOutputHandler;
using System;
using System.Collections.Generic;

namespace StarWarShips.Tests
{
    [TestFixture]
    public class StarShipAppTests
    {
        private Mock<IInputHandler> mockInputHandler;
        private Mock<IShipsResupplyHandler> mockShipsResupplyHandler;
        private Mock<IOutputHandler> mockOutputHandler;
        private Mock<IConsoleWapper> mockConsoleWapper;

        [SetUp]
        public void SetUp()
        {
            mockInputHandler = new Mock<IInputHandler>();
            mockShipsResupplyHandler = new Mock<IShipsResupplyHandler>();
            mockOutputHandler = new Mock<IOutputHandler>();
            mockConsoleWapper = new Mock<IConsoleWapper>();
        }

        [TearDown]
        public void TearDown()
        {
            mockInputHandler = null;
            mockShipsResupplyHandler = null;
            mockOutputHandler = null;
            mockConsoleWapper = null;
        }

        [Test]
        public void Run_ValidData_DisplayShipResupplyDetails()
        {
            //Arrange.
            mockInputHandler.Setup(f => f.GetDistance()).Returns(2);

            var shipsResupplyDetail = new List<ShipResupplyDetail>();

            mockShipsResupplyHandler.Setup(f => f.GetShipsResupplyDetail(2)).Returns(shipsResupplyDetail);

            var starShipApp = new StarShipApp(mockInputHandler.Object, mockShipsResupplyHandler.Object, mockOutputHandler.Object, mockConsoleWapper.Object);

            //Act.
            starShipApp.Run();

            //Assert
            mockConsoleWapper.Verify(f => f.WriteLine(It.IsAny<string>()), Times.Never);
            mockInputHandler.Verify(f => f.GetDistance(), Times.Once);
            mockOutputHandler.Verify(f => f.DisplayShipsResupplyDetail(shipsResupplyDetail), Times.Once);
            mockShipsResupplyHandler.Verify(f => f.GetShipsResupplyDetail(It.IsAny<double>()), Times.Once);
        }

        [Test]
        public void Run_GetDistanceReturnNull_DisplayShipResupplyDetails()
        {
            //Arrange.
            double? distance = null;
            mockInputHandler.Setup(f => f.GetDistance()).Returns(distance);

            var starShipApp = new StarShipApp(mockInputHandler.Object, mockShipsResupplyHandler.Object, mockOutputHandler.Object, mockConsoleWapper.Object);

            //Act.
            starShipApp.Run();

            //Assert
            mockConsoleWapper.Verify(f => f.WriteLine(It.IsAny<string>()), Times.Never);
            mockInputHandler.Verify(f => f.GetDistance(), Times.Once);
            mockOutputHandler.Verify(f => f.DisplayShipsResupplyDetail(It.IsAny<List<ShipResupplyDetail>>()), Times.Never);
            mockShipsResupplyHandler.Verify(f => f.GetShipsResupplyDetail(It.IsAny<double>()), Times.Never);
        }

        [Test]
        public void Run_ShipsResupplyHandlerThrowException_DisplayExceptionDetail()
        {
            //Arrange.
            mockInputHandler.Setup(f => f.GetDistance()).Returns(2);

            mockShipsResupplyHandler.Setup(f => f.GetShipsResupplyDetail(2)).Throws(new Exception("Boom"));

            var starShipApp = new StarShipApp(mockInputHandler.Object, mockShipsResupplyHandler.Object, mockOutputHandler.Object, mockConsoleWapper.Object);

            //Act.
            starShipApp.Run();

            //Assert
            mockConsoleWapper.Verify(f => f.WriteLine(It.IsAny<string>()), Times.Exactly(2));

            string message = $"There is an error occurred during the process, the detail is display below: ";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Once);

            mockConsoleWapper.Verify(f => f.WriteLine("Boom"), Times.Once);
        }

        [Test]
        public void Run_ShipsResupplyHandlerThrowExceptionWithInternalException_DisplayBothExceptionDetail()
        {
            //Arrange.
            mockInputHandler.Setup(f => f.GetDistance()).Returns(2);

            var innerException = new Exception("Boom");

            var exception = new StarWarShipsException("Boom again", innerException);

            mockShipsResupplyHandler.Setup(f => f.GetShipsResupplyDetail(2)).Throws(exception);

            var starShipApp = new StarShipApp(mockInputHandler.Object, mockShipsResupplyHandler.Object, mockOutputHandler.Object, mockConsoleWapper.Object);

            //Act.
            starShipApp.Run();

            //Assert
            mockConsoleWapper.Verify(f => f.WriteLine(It.IsAny<string>()), Times.Exactly(3));

            string message = $"There is an error occurred during the process, the detail is display below: ";
            mockConsoleWapper.Verify(f => f.WriteLine(message), Times.Once);

            mockConsoleWapper.Verify(f => f.WriteLine("Boom"), Times.Once);

            mockConsoleWapper.Verify(f => f.WriteLine("Boom again"), Times.Once);
        }

    }
}
