using Moq;
using NUnit.Framework;
using StarShipsBusinessLayer.ShipsDetailsHandler;
using StarWarApiServiceManager.StarShipsServiceManager;
using StarWarModel.StarShips;
using StarWarModel.StarWarShipException;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StarWarApiServiceManager.Tests
{
    [TestFixture]
    public class ShipsDetailHandlerTests
    {
        private Mock<IStarWarShipServiceManager> mockStarShipServiceManager;

        [SetUp]
        public void Setup()
        {
            mockStarShipServiceManager = new Mock<IStarWarShipServiceManager>();
        }

        [TearDown]
        public void TearDown()
        {
            mockStarShipServiceManager = null;
        }

        [Test]
        public void CombineShipsDetail_StarWarShipServiceManagerThrowException_ThrowStarWarShipsException()
        {
            //Arrange.
            mockStarShipServiceManager.Setup(f => f.GetShipsInformation(null)).ThrowsAsync(new Exception("Boom"));

            var shipsDetailHandler = new ShipsDetailHandler(mockStarShipServiceManager.Object);

            //Act. => Assert.
            var exception = Assert.ThrowsAsync<StarWarShipsException>(async () => await shipsDetailHandler.CombineShipsDetail());

            string expectedMessage = $"An error occurred while trying to combline 0 number of star ships information with current count of ships 0 and the ships information page number 1";
            Assert.AreEqual(expectedMessage, exception.Message);
            Assert.AreEqual("Boom", exception.InnerException.Message);
            Assert.IsInstanceOf<Exception>(exception.InnerException);
        }

        [Test]
        public void CombineShipsDetail_FinalShipCountIsNotEqualToExceptedTotalCount_ThrowStarWarShipsException()
        {
            //Arrange.

            var firstCollection = GetShipsCollection(10, 17);

            var secondCollection = GetShipsCollection(8, 17);

            mockStarShipServiceManager.Setup(f => f.GetShipsInformation(null)).ReturnsAsync(firstCollection);

            mockStarShipServiceManager.Setup(f => f.GetShipsInformation(2)).ReturnsAsync(secondCollection);

            var shipsDetailHandler = new ShipsDetailHandler(mockStarShipServiceManager.Object);

            //Act. => Assert.
            var exception = Assert.ThrowsAsync<StarWarShipsException>(async () => await shipsDetailHandler.CombineShipsDetail());

            string expectedMessage = $"The combined ships list has 18 is not equal to the expected ships nubmer 17.";
            Assert.AreEqual(expectedMessage, exception.Message);
            Assert.IsNull(exception.InnerException);
        }

        [Test]
        public void CombineShipsDetail_urlForNextPageIsNull_ThrowStarWarShipsException()
        {
            //Arrange.

            var collection = GetShipsCollection(10, 17);

            collection.Next = null;

            mockStarShipServiceManager.Setup(f => f.GetShipsInformation(null)).ReturnsAsync(collection);

            var shipsDetailHandler = new ShipsDetailHandler(mockStarShipServiceManager.Object);

            //Act. => Assert.
            var exception = Assert.ThrowsAsync<StarWarShipsException>(async () => await shipsDetailHandler.CombineShipsDetail());

            string expectedMessage = $"The combined ships list has 10 is not equal to the expected ships nubmer 17.";
            Assert.AreEqual(expectedMessage, exception.Message);
            Assert.IsNull(exception.InnerException);

            mockStarShipServiceManager.Verify(f => f.GetShipsInformation(2), Times.Never);
        }

        [Test]
        public async Task CombineShipsDetail_ValidData_ReturnListOfStarShips()
        {
            //Arrange.

            var firstCollection = GetShipsCollection(10, 17);

            var secondCollection = GetShipsCollection(7, 17);

            mockStarShipServiceManager.Setup(f => f.GetShipsInformation(null)).ReturnsAsync(firstCollection);

            mockStarShipServiceManager.Setup(f => f.GetShipsInformation(2)).ReturnsAsync(secondCollection);

            var shipsDetailHandler = new ShipsDetailHandler(mockStarShipServiceManager.Object);

            //Act. 
            var result = await shipsDetailHandler.CombineShipsDetail();

            //Assert.
            Assert.AreEqual(17, result.Count);

            var firstItem = result.First();
            Assert.AreEqual("dummy name", firstItem.Name);
            Assert.AreEqual("dummy consumales", firstItem.Consumables);
            Assert.AreEqual("dummy MGLT", firstItem.MGLT);
        }

        private StarShipsCollection GetShipsCollection(int numberOfShips, int totalAmountofShips)
        {
            var collecton = new StarShipsCollection
            {
                Count = totalAmountofShips,
                Next = "bool"
            };

            var shipList = new List<StarShip>();

            for (int i = 0; i < numberOfShips; i++)
            {
                shipList.Add(new StarShip { Name = "dummy name", Consumables = "dummy consumales", MGLT = "dummy MGLT" });
            }

            collecton.Results = shipList;

            return collecton;
        }
    }
}