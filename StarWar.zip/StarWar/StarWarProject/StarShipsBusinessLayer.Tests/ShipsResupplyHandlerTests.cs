﻿using Moq;
using NUnit.Framework;
using StarShipsBusinessLayer.ShipsDetailsHandler;
using StarShipsBusinessLayer.ShipsResupplyCalculator;
using StarWarModel.StarShips;
using StarWarModel.StarWarShipException;
using System;
using System.Collections.Generic;
using System.Linq;

namespace StarShipsBusinessLayer.Tests
{
    [TestFixture]
    public class ShipsResupplyHandlerTests
    {
        private Mock<IShipsDetailHandler> mockShipsDetailsHandler;
        private Mock<IShipsResupplyCalculator> mockShipsResupplyCalculator;

        [SetUp]
        public void SetUp()
        {
            mockShipsDetailsHandler = new Mock<IShipsDetailHandler>();
            mockShipsResupplyCalculator = new Mock<IShipsResupplyCalculator>();
        }

        [TearDown]
        public void TearDown()
        {
            mockShipsDetailsHandler = null;
            mockShipsResupplyCalculator = null;
        }

        [Test]
        public void GetShipsResupplyDetail_shipsDetailHandlerThrowException_ThrowStarWarShipsException()
        {
            //Arrange.
            mockShipsDetailsHandler.Setup(f => f.CombineShipsDetail()).Throws(new Exception("Boom"));

            var shipsResupplyHandler = new ShipsResupplyHandler.ShipsResupplyHandler(mockShipsDetailsHandler.Object, mockShipsResupplyCalculator.Object);

            //Act. => Assert.
            var excepion = Assert.Throws<StarWarShipsException>( () => shipsResupplyHandler.GetShipsResupplyDetail(200));

            string expectedMessage = "An error occurred while trying to get ships details and process resupply calculation with the distance 200 ";
            Assert.AreEqual(expectedMessage, excepion.Message);
            Assert.AreEqual("Boom", excepion.InnerException.Message);
            Assert.IsInstanceOf<Exception>(excepion.InnerException);         
        }

        [Test]
        public void GetShipsResupplyDetail_ShipsResupplyCalculatorThrowStarWarShipsException_ThrowStarWarShipsException()
        {
            //Arrange.
            var shipList = new List<StarShip>();

            mockShipsDetailsHandler.Setup(f => f.CombineShipsDetail()).ReturnsAsync(shipList);

            mockShipsResupplyCalculator.Setup(f => f.CalculateShipsResupplyStopNumber(shipList)).Throws(new StarWarShipsException("Boom"));

            var shipsResupplyHandler = new ShipsResupplyHandler.ShipsResupplyHandler(mockShipsDetailsHandler.Object, mockShipsResupplyCalculator.Object);

            //Act. => Assert.
            var excepion = Assert.Throws<StarWarShipsException>(() => shipsResupplyHandler.GetShipsResupplyDetail(200));

            Assert.AreEqual("Boom", excepion.Message);
            Assert.IsNull(excepion.InnerException);
        }

        [Test]
        public void GetShipsResupplyDetail_ValidData_ReturnShipsResupplyList()
        {
            //Arrange.
            var shipList = new List<StarShip>();

            mockShipsDetailsHandler.Setup(f => f.CombineShipsDetail()).ReturnsAsync(shipList);

            var shipResupplyList = new List<ShipResupplyDetail>
            {
                new ShipResupplyDetail
                {
                    Name = "dummy",
                    Consumables = "boom",
                    MGLT = "boom",
                    NumberOfStops = 0
                }
            };

            mockShipsResupplyCalculator.Setup(f => f.CalculateShipsResupplyStopNumber(shipList)).Returns(shipResupplyList);

            var shipsResupplyHandler = new ShipsResupplyHandler.ShipsResupplyHandler(mockShipsDetailsHandler.Object, mockShipsResupplyCalculator.Object);

            //Act. 
            var result =  shipsResupplyHandler.GetShipsResupplyDetail(200);

            //Assert.
            Assert.AreEqual(1, result.Count);

            var firstItem = result.First();
            Assert.AreEqual("dummy", firstItem.Name);
            Assert.AreEqual("boom", firstItem.Consumables);
            Assert.AreEqual("boom", firstItem.MGLT);
            Assert.AreEqual(0, firstItem.NumberOfStops);
        }
    }
}
