using NUnit.Framework;
using StarWarModel.StarShips;
using System;
using System.Collections.Generic;
using System.Linq;

namespace StarShipsBusinessLayer.Tests
{
    [TestFixture]
    public class ShipsResupplyCalculatorTests
    {

        [Test]
        public void CalculateShipsResupplyStopNumber_NotSupportConsumables_ThrowNotSupportedException()
        {
            //Arrange.
            var shipList = new List<StarShip>
            {
                new StarShip { Name = "dummy", Consumables = "Boom", MGLT = "40"}
            };

            var shipsResupplyCalculator = new ShipsResupplyCalculator.ShipsResupplyCalculator();

            //Act. => Assert.
            var exception = Assert.Throws<NotSupportedException>( () => shipsResupplyCalculator.CalculateShipsResupplyStopNumber(shipList));

            string expectedMessage = "convert consumables Boom to hours is not support";
            Assert.AreEqual(expectedMessage, exception.Message);
        }

        [Test]
        public void CalculateShipsResupplyStopNumber_ValidData_ReturnShipResupplyList()
        {
            //Arrange.
            var shipList = GetShipList();

            var shipsResupplyCalculator = new ShipsResupplyCalculator.ShipsResupplyCalculator();

            shipsResupplyCalculator.Distance = 30000;

            //Act. 
            var result = shipsResupplyCalculator.CalculateShipsResupplyStopNumber(shipList);

            //Assert
            Assert.AreEqual(11, result.Count);

            var item = result.First();
            Assert.AreEqual(0, item.NumberOfStops);
            Assert.AreEqual("dummy 1", item.Name);

            item = result.ElementAt(1);
            Assert.AreEqual(1, item.NumberOfStops);
            Assert.AreEqual("dummy 2", item.Name);

            item = result.ElementAt(2);
            Assert.AreEqual(4, item.NumberOfStops);
            Assert.AreEqual("dummy 3", item.Name);

            item = result.ElementAt(3);
            Assert.AreEqual(31, item.NumberOfStops);
            Assert.AreEqual("dummy 4", item.Name);

            item = result.ElementAt(4);
            Assert.AreEqual(749, item.NumberOfStops);
            Assert.AreEqual("dummy 5", item.Name);

            item = result.ElementAt(5);
            Assert.AreEqual(0, item.NumberOfStops);
            Assert.AreEqual("dummy 6", item.Name);

            item = result.ElementAt(6);
            Assert.IsNull(item.NumberOfStops);
            Assert.AreEqual("dummy 7", item.Name);

            item = result.ElementAt(7);
            Assert.IsNull(item.NumberOfStops);
            Assert.AreEqual("dummy 8", item.Name);

            item = result.ElementAt(8);
            Assert.IsNull(item.NumberOfStops);
            Assert.AreEqual("dummy 9", item.Name);

            item = result.ElementAt(9);
            Assert.IsNull(item.NumberOfStops);
            Assert.AreEqual("dummy 10", item.Name);

            item = result.ElementAt(10);
            Assert.IsNull(item.NumberOfStops);
            Assert.AreEqual("dummy 11", item.Name);
        }



        private List<StarShip> GetShipList()
        {
            var shipList = new List<StarShip>
            {
                // consumalbes' unit is year and valid MGLT
                new StarShip { Name = "dummy 1", Consumables = "2 years", MGLT = "20" },

                // consumables' unit is month and valid MGLT
                new StarShip { Name = "dummy 2", Consumables = "2 months", MGLT = "20"},

                //consumables unit is week and valid MGLT
                new StarShip { Name = "dummy 3", Consumables = "2 weeks", MGLT = "20"},

                //consumables unit is day and valid MGLT
                new StarShip { Name = "dummy 4", Consumables = "2 days", MGLT = "20"},

                //consumables unit is hour and valid MGLT
                new StarShip { Name = "dummy 5", Consumables = "2 hours", MGLT = "20"},

                //The distance it can travle without resupply is equalt to the travle distance
                new StarShip { Name = "dummy 6", Consumables = "30000 hours", MGLT = "1"},

                //consumables is unknown and valid MGLT
                new StarShip { Name = "dummy 7", Consumables = "unknown", MGLT = "20"},

                //consumables is null and valid MGLT
                new StarShip { Name = "dummy 8", Consumables = null, MGLT = "20"},

                //consumables is valid and MGLT is unknown
                new StarShip { Name = "dummy 9", Consumables = "2 months", MGLT = "unknown"},

                //consumables is valid and MGLT is null
                new StarShip { Name = "dummy 10", Consumables = "2 months", MGLT = null},

                //consumables is invalid and MGLT is invalid
                new StarShip { Name = "dummy 11", Consumables = "unknown", MGLT = null}

            };

            return shipList;
        }
    }
}